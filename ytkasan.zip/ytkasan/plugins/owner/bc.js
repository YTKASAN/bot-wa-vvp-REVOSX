const fs = require('fs');

exports.run = {
  usage: ['bc'],
  hidden: [''],
  use: 'jeda|pesan',
  category: 'tools',
  async: async (m, { client, Func, command, isPrefix, args, users }) => {
    try {
      const [jeda, pesan] = args.join(' ').split('|');
      if (!jeda || !pesan) {
        return client.reply(m.chat, `*• Example :* ${isPrefix + command} 5|Hello World!`, m);
      }

      // Cek keberadaan file nomor.json dan membacanya
      try {
        const fileData = await fs.readFile('./media/json/nomor.json', 'utf8');
        const nomor = JSON.parse(fileData);

        for (let i = 0; i < nomor.length; i++) {
          await client.reply(nomor[i] + '@c.us', pesan, null);
          await Func.sleep(jeda * 1000);
        }

        m.reply('Broadcast pesan berhasil!');
      } catch (err) {
        if (err.code === 'ENOENT') {
          m.reply('File nomor.json tidak ditemukan!');
        } else {
          throw err;
        }
      }
    } catch (e) {
      console.log(e);
      m.reply('Gagal mengirim broadcast pesan!');
    }
  },
  error: false,
  owner: true,
  location: __filename
};