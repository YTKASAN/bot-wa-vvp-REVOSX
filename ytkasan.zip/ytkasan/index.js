const axios = require('axios');
const chalk = require('chalk');
const CFonts = require('cfonts');
const { Function: Func } = new (require('@neoxr/wb'));
const path = require('path');
const { spawn } = require('child_process');

const rl = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

const showLoadingAnimation = () => {
  const frames = ['|', '/', '-', '\\', '|', '/', '-', '\\', '', '✅'];
  let i = 0;
  return setInterval(() => {
    process.stdout.write(`\r${chalk.green('Loading ...')} ${frames[i]}`);
    i = (i + 1) % frames.length;
  }, 6000);
};

const runScript = async () => {
  try {
    const ipServer = await fetchData('https://api64.ipify.org?format=json')
      .then(data => data.ip);

    process.stdout.write(chalk.yellow.bold(`   ,--------------------------------------------------------------------------.\n   |                                                                          |\n   |  ██╗   ██╗ █████╗ ███╗   ██╗ █████╗     ███╗   ███╗██╗██╗  ██╗██╗   ██╗  |\n   |  ╚██╗ ██╔╝██╔══██╗████╗  ██║██╔══██╗    ████╗ ████║██║██║ ██╔╝██║   ██║  |\n   |   ╚████╔╝ ███████║██╔██╗ ██║███████║    ██╔████╔██║██║█████╔╝ ██║   ██║  |\n   |    ╚██╔╝  ██╔══██║██║╚██╗██║██╔══██║    ██║╚██╔╝██║██║██╔═██╗ ██║   ██║  |\n   |     ██║   ██║  ██║██║ ╚████║██║  ██║    ██║ ╚═╝ ██║██║██║  ██╗╚██████╔╝  |\n   |     ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚═╝╚═╝  ╚═╝ ╚═════╝   |\n   |                                                                          |\n   |                                                                          |\n   |                                                              © YanaMiku  |\n   |                                                                          |\n   |  Terimakasih Atas Pembelian Script nya. Jika Terdapat Error Pada Script, |\n   |                        Harap Lapor Ke YanaMiku!!                         |\n   |                                                                          |\n   \`--------------------------------------------------------------------------'\nIp Server : ${ipServer}\nJika ip server tidak tervalidasi, kirim IP ke YanaMiku.\n\n`));

    process.stdout.write(chalk.red.bold(`Developer : YanaMiku\nKontak : +62 857-9358-9243I\n\nJika ada yang memperjual-belikan script ini (bukan dari developer), Lapor ke Developer (Dapat Hadiah)\n\n`))

    const username = await askQuestion(chalk.blue.bold(`Masukkan Username :\n`));

    const accessJsonUrl = `https://ytkasan-database-user.vercel.app/api?username=${username}`;
    const yanamikuData = await fetchData(accessJsonUrl);

    if (!yanamikuData[username]) {
      askQuestion(chalk.red(`Username ${username} tidak ditemukan dalam data Yanamiku!\n`));
      rl.close();
      return;
    }

    const userData = yanamikuData[username];

    const loadingAnimationInterval = showLoadingAnimation();

    await simulateAsynchronousProcess(500);

    clearInterval(loadingAnimationInterval);

    // Periksa apakah IP server sesuai
    if (ipServer === userData.ip) {
      process.stdout.write(chalk.green(`Ip Server Tervalidasi ✅\n`));
    } else {
      process.stdout.write(chalk.red('Ip Server Tidak Tervalidasi ❌\n'));
      rl.close();
      return;
    }

    const code = await askQuestion(chalk.yellow.bold('Masukkan code verifikasi: \n'));

    // Periksa apakah code verifikasi sesuai
    if (code.trim() !== userData.code_verifikasi) {
      askQuestion(chalk.red('Code verifikasi salah\n'));
      process.exit(1);
    }

    // Periksa apakah pengguna memiliki izin
    if (!userData.acces) {
      process.stdout.write(chalk.red.bold(`PENGGUNA TIDAK DI IZINKAN!!

╭❒
┆◍ Company : YanaMiku
┆◍ Contact : +62 857-9358-9243
┆◍ Developer : Iyuzaki Yanagi
┆◍ Website : https://yanamiku.shop
╰────────────❒

Contribution :
○ Iyuzaki Yanagi
○ Wildan Izzuddin
`));
      rl.close();
      return;
    }

    process.stdout.write(chalk.yellow.bold(`Terima Kasih Telah Membeli Script Ini ❤️, I hope you are happy with my script, Jika Terdapat Error Harap Lapor Kepada YanaMiku!!

╭❒\n┆◍ Company : YanaMiku\n┆◍ Contact : +62 857-9358-9243\n┆◍ Developer : Iyuzaki Yanagi\n┆◍ Website : https://yanamiku.shop\n╰────────────❒\n\nContribution :\n○ Iyuzaki Yanagi\n○ Wildan Izzudin\n`));

    if (process.argv.includes('--server')) {
      require('./server');
    }

    require('dotenv').config();
    require('rootpath')();

    const unhandledRejections = new Map();
    process.on('unhandledRejection', (reason, promise) => {
      unhandledRejections.set(promise, reason);
      console.log('Unhandled Rejection at:', promise, 'reason:', reason);
    });
    process.on('rejectionHandled', (promise) => {
      unhandledRejections.delete(promise);
    });
    process.on('Something went wrong', function (err) {
      console.log('Caught exception: ', err);
    });

    function start() {
      const args = [path.join(__dirname, 'client.js'), ...process.argv.slice(2)];
      const p = spawn(process.argv[0], args, { stdio: ['inherit', 'inherit', 'inherit', 'ipc'] });

      p.on('message', data => {
        if (data == 'reset') {
          console.log('Restarting...');
          p.kill();
        }
      });

      p.on('exit', code => {
        console.error('Exited with code:', code);
        start();
      });
    }

    start();

    rl.close();
  } catch (error) {
    console.log(chalk.red.bold("Failed to retrieve data from Yanamiku API:", error.message + '\n'));  // Output pesan error
  }
};

const askQuestion = (question) => {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
};

const fetchData = async (url) => {
  return fetchDataWithRetry(url, 3);
};

const fetchDataWithRetry = async (url, retries = 3, config = {}) => {
  try {
    const { data } = await axios.get(url, { ...config, timeout: 10000 });
    return data;
  } catch (error) {
    if (retries === 0 || error.response) {
      throw error;
    }
    console.log(chalk.yellow(`Retrying... (${3 - retries + 1})`));
    return fetchDataWithRetry(url, retries - 1, config);
  }
};

const simulateAsynchronousProcess = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
};

// Jalankan skrip utama
runScript();